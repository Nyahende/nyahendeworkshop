$(document).ready(function(){
    $('#livestock').click(function(){
        $('.livestockul').slideToggle();
    });
});